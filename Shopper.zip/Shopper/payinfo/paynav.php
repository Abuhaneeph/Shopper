<div class="w3-container">

	<div id="top-bar" class="w3-container w3-white">
    <a href="../index.php" class="w3-bar-item w3-button w3-left w3-mobile "><img src="../themes/images/logo.png" class="site_logo" alt=""></a>						
	<a href="../pages/cart.php" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Your Cart</a>
      <a href="../pages/checkout.php" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Checkout</a>
     							
</div>