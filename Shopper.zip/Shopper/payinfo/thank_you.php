<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
    
	<?php include("../partials/header.php")?>

 <?php 
   if(!isset($_SESSION['transaction'])){ 

        header("Location: ../index.php");
    }  
    
?>
    <body class="w3-white">		
		<?php include("paynav.php") ?>		
			<section class="w3-white w3-container">
			<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
			
			</section>
            <div class="w3-center w3-white">			
			<section class="w3-center">				
				<div class="w3-center">
					<div class=" w3-center">					
						
					   <?php if(isset($_GET['success']) && isset($_SESSION['transaction'])){ ?>
                        <div class="w3-center">
                        <h3><?php echo $_GET['success'] ?></h3>
                        <i class="fas fa-handshake" style="font-size:50px;color:##FF4500;"></i>
						 <p style="font-weight:bold;font-size:15px;"> <?php echo "Your ORDER ID: " .$_SESSION['order']." has been created" ?><p>	
						<p style="font-weight:15px;">	Check you email shortly for a confirmation of your order.
                        Pease keep it for your records.
                        </p>
                        <p style="font-weight:15px;">Download the Receipt below for reference</p>
                        <a href="invoice.php" style="font-size:25px;" class="w3-text-deep-orange"><i class="fa fa-file-pdf" style='font-size:25px;' class="w3-text-deep-orange"></i>Invoice</a>
                        
	
                        <div>	
							
						<!-- Set up a container element for the button -->

                        
						<?php }else{ ?>
						
						   <?php header("Location: ../index.php")?>
						<?php } ?>
					</div>
							
				</div>
			</section>
			<div class="w3-container">
			
			<?php include("../partials/footer.php")?>
                       </div>
    </body>
</html>
<?php
include("mail.php");

?>
