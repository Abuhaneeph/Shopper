 <?php 
include ("../config/config.php");
session_start();
 ob_start();

require('../fpdf/fpdf.php');
if(isset($_SESSION['order']) && isset($_SESSION['transaction'])){
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->SetDrawColor(0,0,0);
$pdf->SetTextColor(0,0,0);
$pdf->Cell(0,10,'Shopping Invoice',1,1,'C');
$pdf->Cell(95,10,'',0,1);

$pdf->Cell(50,20,'Payment ID',1,0,'C');
$pdf->Cell(55,20,'Order ID',1,0,'C');
$pdf->Cell(85,20,'Transaction ID',1,1,'C');

$order_id=$_SESSION['order'];
$sql="SELECT * FROM payments_info WHERE order_id=$order_id";
$rslt=mysqli_query($connect,$sql);

while($row=mysqli_fetch_array($rslt)){
    $pdf->Cell(50,15,$row['payment_id'],1,0,'C');
    $pdf->Cell(55,15,$row['order_id'],1,0,'C');
    $pdf->Cell(85,15,$row['transaction_id'],1,1,'C');
    

}
$pdf->Cell(95,10,'',0,1);
$pdf->Cell(82,15,'Product Name',1,0);
$pdf->Cell(35,15,'Price',1,0,'C');
$pdf->Cell(35,15,'Quantity',1,0,'C');
$pdf->Cell(38,15,'Total Price',1,1,'C');

$products=$_SESSION['products'];

$total = 0;
	
foreach ($products as $key => $value) {
	

$pdf->Cell(82,15,$value['product_name'],1,0);
$pdf->Cell(35,15,$value['product_quantity'],1,0,'C');
$pdf->Cell(35,15,$value['product_price'],1,0,'C');
$pdf->Cell(38,15,"$".number_format($value['product_quantity'] * $value['product_price']),1,1,'C');
$total = $total + $value['product_quantity'] * $value['product_price'];
}

$pdf->Cell(190,20,'',0,1);
$pdf->Cell(60,20,'',0,0);
$pdf->Cell(60,20,'Amount',1,0,'C');
$pdf->Cell(70,20,"$ ".number_format($total),1,1,'C');






$pdf->Output();
ob_end_flush(); 
session_unset();
session_destroy();

}else{
    header("Location: ../index.php");
}
