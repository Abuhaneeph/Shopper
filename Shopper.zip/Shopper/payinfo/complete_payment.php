<?php
session_start();
include("../config/config.php");

if(isset($_GET['transaction_id'])){
  $order_date=date("Y-m-d h:i:s");
  $stmt =$connect->prepare("INSERT INTO orders (order_cost, order_status,order_name,order_email,order_phone,order_city,order_address,order_date) VALUES (?, ?, ?,?,?,?,?,?)");

  $total=$_SESSION['total'];
  $name=$_SESSION['name'];
  $email=$_SESSION['email'];
  $tel=$_SESSION['tel'];
  $city=$_SESSION['city'];
  $address=$_SESSION['address'];
  $cost="paid";
   // Bind variables to the prepared statement as parameters
   $stmt->bind_param("isssssss", $total,$cost, $name,$email,$tel,$city,$address,$order_date);
   if(!$stmt->execute()){
         header("Location:index.php");
   }else{
  
   foreach($_SESSION['cart'] as $id=>$product){
  
  $product_id=$product['product_id'];
  $product_name=$product['product_name'];
  $product_image=$product['product_image'];
  $product_price=$product['product_price'];
  $product_quantity=$product['product_quantity'];
  
  //For each insert it to the order_items tables
  $order_id= $stmt->insert_id; 
  $stmt1 =$connect->prepare("INSERT INTO order_items (order_id, product_id,product_name,product_image,product_price,product_quantity,username,order_date) VALUES (?, ?, ?,?,?,?,?,?)");
  $stmt1->bind_param("iissiiss", $order_id, $product_id, $product_name,$product_image,$product_price,$product_quantity,$name,$order_date);
  $stmt1->execute();
   }
   

   //set products to hold the products
  $_SESSION['products']=$_SESSION['cart'];
  unset($_SESSION['cart']);
  
  //set order to hold the order
  $_SESSION['order']=$order_id;
  

  
  //set transaction_id
  $transaction_id=$_GET['transaction_id'];
  $_SESSION['transaction']=$transaction_id;
  
 
  $payment_date=date("Y-m-d h:i:s");


  //store payment info
 $stmt1=$connect->prepare("INSERT payments_info(order_id,transaction_id,payment_date) VALUES(?,?,?) ");

 $stmt1->bind_param("iss",$order_id,$transaction_id,$payment_date);
 $stmt1->execute();

 header("Location:thank_you.php?success=Thanks for shopping with us");   
}
}else{
  header("Location: ../index.php");
    exit;
}