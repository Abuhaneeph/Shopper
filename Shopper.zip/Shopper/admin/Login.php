<?php
include_once("../config/config.php");
session_start();

$nameErr = $passErr =$username_err=" ";
$name = $pass = $success=" ";
 function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if (isset($_POST['login'])) {
   if (empty($_POST["Username"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["Username"]);
  }  // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }

 if(empty($_POST["Password"])) {
    $passErr = "Password is required";
  }elseif(strlen(trim($_POST["Password"])) < 6){
        $passErr = "Password must have atleast 6 characters.";
    }
   else {
    $pass = test_input($_POST["Password"]);
     $sql= "SELECT * FROM users WHERE Username=? and Password=?";
      if($stmt = mysqli_prepare($connect, $sql)){
      mysqli_stmt_bind_param($stmt, "ss", $name,$pass);
       mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $result=mysqli_stmt_num_rows($stmt);
      if($result>0){

        $_SESSION["admin"]=$name;
       $success="You have signed up successfully";
       header("Location:addproduct.php");
    } else{
      $username_err="This Email address or password is not Found";
      }
        }
     }

}



?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
      </head>
    <body>
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <form action="Login.php" method="POST" class="decor">
          <div class="form-left-decoration"></div>
          <div class="form-right-decoration"></div>
          <div class="circle"></div>
          <div class="form-inner2">
            <h1 class="w3-center">LOGIN FORM</h1>
            <p class="w3-text-red">Please fill out the below infomation *</p>
            
            <div class="input-container">
              <i class="fa fa-user icon"></i>
              <input class="input-field" type="text" placeholder="Username" name="Username" value="<?php echo $name ?>">
              <span><?php echo $nameErr; ?></span>            
            </div>
            
  <div class="input-container">
    <i class="fa fa-key icon"></i>
    <input class="input-field" type="password" placeholder="Password" name="Password" value="<?php echo $pass ?>">
  <span>  <?php echo $passErr; ?> </span>
  </div>
   
  
  
            <button type="submit" name="login" >LOGIN</button>
            <span><?php echo $success ?></span>
          </div>
        </form>
            <script src="" async defer></script>
    </body>
</html>