<?php
include ("../config/config.php");
$id=$_GET['id'];
$sql="DELETE FROM PRODUCTS WHERE Product_id='$id'";
$query=mysqli_query($connect,$sql);
if($query){
    header("Location:display.php");
}

?>