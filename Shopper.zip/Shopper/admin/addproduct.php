<?php
session_start();

if($_SESSION["admin"]==""){
    header("Location:login.php");
}
?>

<?php include "header.php" ?>

<?php include_once "../config/config.php" ?>

<?php 
               $success = $error=""; 
                if(isset($_POST["submit"])){
                  

                  $image=$_FILES["pimage"]["name"];

                 $name=$_POST["pnm"];
                 $price=$_POST["pprice"];
                 $size=$_POST["psize"];
                 $colour=$_POST["pcolour"];
                 $quantity=$_POST["pqty"];
                 $category=$_POST["pcategory"];
                 $desc=$_POST["pdesc"];
                 if(empty($name)||empty($price)||empty($quantity)||empty($category)||empty($desc)||empty($image)||empty($size)||empty($colour)){
                  $error="All the fields are required";
                }else{
                  move_uploaded_file($_FILES['pimage']['tmp_name'], "img/$image");
                  $sql="INSERT INTO PRODUCTS VALUES ('','$name','$category','$price','$image','$quantity','$desc','$size','$colour')";
                  $res=mysqli_query($connect,$sql);
                  if($res){
                    $success="Products added successfully";
                  }
                }
                
                }
                 
              



              ?> 

<div class="grid_10">
            <div class="box round first">
                <h2>
                   Add Product</h2>
                <div class="block">
                   <form method="post" name="form1" enctype="multipart/form-data">
                     <table>
                         <tr>
                             <td>Product Name</td><td><input type="text" name="pnm" /></td>
                           </tr>
                            <tr>
                           <td>Product Price</td>  <td><input type="text" name="pprice" /></td>
                            <tr>
                            <tr>
                           <td>Product Size</td>  <td><input type="text" name="psize" /></td>
                            <tr>
                            <tr>
                           <td>Product Colour</td>  <td><input type="text" name="pcolour" /></td>
                            <tr>
                        <tr>
                           <td>Product Quantity</td>  <td><input type="text" name="pqty" /></td>
                            <tr>
                         <tr>
                           <td>Product Image</td>  <td><input type="file" name="pimage" /></td>
                            <tr>
                         <tr>
                           <td>Product Category</td>
                           <td><select name="pcategory">
                               <option value="Electronic & Accessories">Electronic & Accessories</option>
                               <option value="Men & Women Clothes">Men & Women Clothes</option>
                               <option value="Kids & Babies Clothes">Kids & Babies Clothes</option>
                               <option value="Fashion and Beauty">Fashion and Beauty</option>
                           </select></td>
                            </tr>
                           <tr>
                           <td>Product Description</td>  <td><textarea cols="15" rows="10" name="pdesc"></textarea></td>
                            <tr>
                            <tr>
                               <td colspan="2" align="center"><input type="submit" name="submit" value="ADD PRODUCT" /></td>
                               <span><?php echo $error ?></span> 
                            <span><?php echo $success ?></span> 
                              </tr>
                            
                     </table>

                   </form>
                  
                    </div>
                </div>
            </div>


<?php include "footer.php" ?>
</body>
</html>