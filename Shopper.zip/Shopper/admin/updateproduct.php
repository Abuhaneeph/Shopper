<?php
session_start();

if($_SESSION["admin"]==""){
    header("Location:login.php");
}

if($_SESSION["display"]==""){
  header("Location:show.php");
}
  $id=$_GET['id'];
  

?>

<?php include "header.php" ?>

<?php include_once "../config/config.php" ?>
<?php 
$sql="SELECT * FROM PRODUCTS WHERE PRODUCT_ID='$id'";
$result=mysqli_query($connect,$sql);

?>

<?php 

	
               $success = $error=""; 
                if(isset($_POST["submit"])){
                  

                  $image=$_FILES["pimage"]["name"];

                 $name=$_POST["pnm"];
                 $price=$_POST["pprice"];
                 $size=$_POST["psize"];
                 $colour=$_POST["pcolour"];
                 $quantity=$_POST["pqty"];
                 $category=$_POST["pcategory"];
                 $desc=$_POST["pdesc"];
                 if(empty($name)||empty($price)||empty($quantity)||empty($category)||empty($desc)||empty($image)||empty($size)||empty($colour)){
                  $error="All the fields are required";
                }else{
                  
                  move_uploaded_file($_FILES['pimage']['tmp_name'], "img/$image");
                 
                  $query="UPDATE PRODUCTS SET Product_name='$name',Product_category='$category',Product_price='$price',Product_image='$image',Product_quantity='$quantity',Product_desc='$desc',Product_size='$size',Product_colour='$colour' WHERE Product_id='$id'";
                  $res=mysqli_query($connect,$query);
                  if($res){
                    $success="Products updated added successfully";
                  }
                }
                
                }
                 
              


              ?> 

<div class="grid_10">
            <div class="box round first">
                <h2>
                   Update Product</h2>
                <div class="block">
                   <form method="post" name="form1" enctype="multipart/form-data">
                  
                   <table>
                   <?php
                   while($row=mysqli_fetch_array($result)){
                   ?>  
                         <tr>
                             <td>Product Name</td><td><input type="text" name="pnm" value="<?php echo $row['Product_name'] ?>" /></td>
                           </tr>
                            <tr>
                           <td>Product Price</td>  <td><input type="text" name="pprice" value="<?php echo $row['Product_price'] ?>" /></td>
                            <tr>
                            <tr>
                           <td>Product Size</td>  <td><input type="text" name="psize" value="<?php echo $row['Product_size'] ?>" /></td>
                            <tr>
                            <tr>
                           <td>Product Colour</td>  <td><input type="text" name="pcolour" value="<?php echo $row['Product_colour'] ?>" /></td>
                            <tr>
                        <tr>
                           <td>Product Quantity</td>  <td><input type="text" name="pqty" value="<?php echo $row['Product_quantity'] ?>" /></td>
                            <tr>
                         <tr>
                           <td>Product Image</td>  <td><input type="file" name="pimage" value="<?php echo $row['Product_image'] ?>" /></td>
                            <tr>
                         <tr>
                           <td>Product Category</td>
                           <td><select name="pcategory">
                               <option value="Electronic & Accessories">Electronic & Accessories</option>
                               <option value="Men & Women Clothes">Men & Women Clothes</option>
                               <option value="Kids & Babies Clothes">Kids & Babies Clothes</option>
                               <option value="Fashion and Beauty">Fashion and Beauty</option>
                           </select></td>
                            </tr>
                           <tr>
                           <td>Product Description</td>  <td><textarea cols="15" rows="10" name="pdesc" ><?php echo $row['Product_desc'] ?></textarea></td>
                            <tr>
                            <tr>
                               <td colspan="2" align="center"><input type="submit" name="submit" value="UPDATE PRODUCT" /></td>
                               <span><?php echo $error ?></span> 
                            <span><?php echo $success ?></span> 
                              </tr>
                              <?php
                   }
                   ?>    
                     </table>
                
              
                   </form>
                  
                    </div>
                </div>
            </div>


<?php include "footer.php" ?>
</body>
<script>
  form.addEventListener('submit',(e)=>{
     window.reload;
  })
  </script>
</html>