
<div class="grid_2">
            <div class="box sidemenu">
                <div class="block" id="section-menu">
                    <ul class="section menu">
                        <li><a class="menuitem" href=#>Menu 1</a>
                            <ul class="submenu">
                                <li><a href="addproduct.php">Add product</a> </li>
                            

                            </ul>
                        </li>
                        
                        
                       
                    </ul>
                </div>
            </div>
        </div>