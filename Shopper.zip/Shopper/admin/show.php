<?php
session_start();
include_once("../config/config.php");
if($_SESSION["admin"]==""){
  header("Location:login.php");
}
?>
<?php include "header.php" ?>

<?php include_once "../config/config.php" ?>

<?php

if(isset($_GET["page"]))
{
	$page=$_GET["page"];
}else{
	$page=1;
}
$numPerPage=10;
$start_from=($page-1)*4;
$sql1 = "SELECT * FROM products LIMIT $start_from,$numPerPage";
$result1=mysqli_query($connect,$sql1);

?>

<div class="grid_10">
            <div class="box round first">
                <h2>
                   List of Products</h2>
                <div class="block">
                <table border="1px">
<tr>
  <th>Products Name</th>
  <th>Products Category</th>
    <th>Products Price</th>
    
    <th>Products Quantity</th>
    
    <th>Products Size</th>
    <th>Products Colour</th>
    <th>Update Products</th>
    <th>Delete Products</th> 
</tr>
<?php
while($row=mysqli_fetch_array($result1)){
?>
<tr>
<td><?php echo $row['Product_name'] ?></td>
<td><?php echo $row['Product_category'] ?></td>
<td><?php echo $row['Product_price'] ?></td>
<td><?php echo $row['Product_quantity'] ?></td>

<td><?php echo $row['Product_size'] ?></td>
<td><?php echo $row['Product_colour'] ?></td>
<td><a href="updateproduct.php?id=<?php echo $row['Product_id']?>">Update</a></td>
<td><a href="delete.php?id=<?php echo $row['Product_id']?>">Delete</a></td>


</tr>
<?php
}
?>
</table>

<?php
												$sql="SELECT * FROM products";
												$result=mysqli_query($connect,$sql);
												$total_records=mysqli_num_rows($result);
												$total_pages=ceil($total_records/$numPerPage);
												for($i=1;$i<=$total_pages;$i++){
													echo "<a href='show.php?page=".$i."'>".$i."</a>";
												}
                        $_SESSION['display']="Display";
												?>
										</div>
<?php

?>
<style>
 
 tr:nth-child(even) {background-color: #00FFFF;}
   tr:nth-child(odd) {background-color: #00CED1;}



  th{
     padding: 5px;
   }
   td{
       padding:5px;
       text-align: center;
   }
   a{
     text-decoration: none;
     display:block;
     colour:green;
     text-align:center;
   }
   </style>



</body>

</html>