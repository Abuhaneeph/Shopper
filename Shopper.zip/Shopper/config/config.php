<?php 



$connect = mysqli_connect("localhost","<USERNAME>","<PASSWORD>","<DB NAME>");



