<?php include("../config/config.php") ?>
<?php

$category=$_GET["id"];
if(isset($_GET["page"]))
{
	$page=$_GET["page"];
}else{
	$page=1;
}
$numPerPage=3;
$start_from=($page-1)*4;
$sql = "SELECT * FROM products WHERE Product_category LIKE '$category%' LIMIT $start_from,$numPerPage";
$result=mysqli_query($connect,$sql);

?>


<!DOCTYPE html>
<html lang="en">

	<?php include("../partials/header.php") ?>
    <body>		
		<?php include("../partials/nav.php") ?>
			<section class="header_text sub">
			<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
				<h4><span>New products</span></h4>
			</section>
			<section class="main-content">
				
				<div class="row w3-margin">						
					<div class="span9">								
						<ul class="thumbnails listing-products">
						<?php if(mysqli_num_rows($result)>0){ ?>
						<?php While($row=mysqli_fetch_array($result)){ ?>
							<li class="span3">
								<div class="product-box ">
									<span class="sale_tag"></span>												
									<a href="product_detail.php?id=<?php echo $row['Product_id']?>&category=<?php echo $row['Product_category']?>"><img alt="" style="width:200px; height:150px" src="../admin/img/<?php echo $row['Product_image'] ?>"></a><br/>
									<a href="product_detail.php?id=<?php echo $row['Product_id']?>&category=<?php echo $row['Product_category']?>" style="font-weight:bold;"><?php echo $row['Product_name'] ?></a><br/>
									<a href="product_detail.php?id=<?php echo $row['Product_id']?>&category=<?php echo $row['Product_category']?>" class="w3-text-deep-orange"><?php echo $row['Product_category'] ?></a>
									<p class="price">$<?php echo $row['Product_price'] ?></p>
								</div>
							</li> 
							<?php } ?>
							</ul>
						
						      
							<hr>
						<?php }else{?>
					    
						
						<p>No records found</p>								
						
						<?php }?>
						<div class="pagination pagination-small pagination-centered">
							<ul>
							<?php
												$sql1="SELECT * FROM products WHERE Product_category LIKE $category%";
												$result1=mysqli_query($connect,$sql1);
												$total_records=mysqli_num_rows($result1);
												$total_pages=ceil($total_records/$numPerPage);
												for($i=1;$i<=$total_pages;$i++){ ?>
							               <li>  <a href='products.php?page=<?php echo $i; ?>&id=<?php echo $category?>'><?php echo $i; ?></a></li>
							                  <?php
												}
												?>
							
													
							</ul>
						</div>
					</div>
					
			<?php include("../partials/subcategory.php") ?>
			<?php include ("../partials/random.php") ?>
			<?php include("../partials/bestseller.php") ?>

		         		
 <?php include("../partials/footer.php") ?>
    </body>
</html>