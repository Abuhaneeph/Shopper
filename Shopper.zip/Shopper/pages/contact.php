<?php
include("../config/config.php");

require '../mailer/PHPMailer.php';
require '../mailer/Exception.php';
require '../mailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
		
$nameErr=$emailErr=$bodyErr=$subjErr="";
$name=$email=$body=$subj="";
 function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if (isset($_POST['submit'])) {
   if (empty($_POST["user"])) {
    $nameErr = "Name is required";
	
  }else{
	$name = test_input($_POST["user"]);
    if(strlen($name) < 3){
		$name="";
		$nameErr="Enter a Valid name";
	}
	if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
		$name="";
		$nameErr = "Only Name with letters and white space allowed";
	  }
	}
    
	if(empty($_POST['subj'])){
		$subjErr="Subject is required";
	}else{
		$subj=test_input($_POST['subj']);
       if(strlen($subj)< 3){
		$subj="";
		$subjErr="The suject should have atleast three characters";
	   }
	   if (!preg_match("/^[a-zA-Z-' ]*$/",$subj)) {
		$subj="";
		$subjErr = "Only Name with letters and white space allowed";
	  }
	}
	
	
	
	if (empty($_POST["email"])) {
		$emailErr = "Email is required";
	  } else {
		$email = test_input($_POST["email"]);
	  
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		
		$email="";
		$emailErr = "Invalid email format";
	  }
	}
	  if(empty($_POST['body'])){
		$bodyErr="Message is required";
	  }else{
		$body=test_input($_POST["body"]);
		if(strlen($body)< 10){
         $body="";
		 $bodyErr="Your Message should atleast have 10 characters";
		}
	  }
	 
	 if($name && $email && $subj && $body !=""){
		
		//These must be at the top of your script, not inside a function
		
		//Load Composer's autoloader
		
		//Create an instance; passing `true` enables exceptions
		$mail = new PHPMailer(true);
		
		try {
			//Server settings
			                  //Enable verbose debug output
			$mail->isSMTP();                                            //Send using SMTP
			$mail->Host       = 'panel21.harmonweb.net';                   //Set the SMTP server to send through
			$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
			$mail->Username   = 'abu@abuhaneephconcepts.com.ng';                     //SMTP username
			$mail->Password   = 'nd.i}TsymkIF';                               //SMTP password
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
			$mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
		
			//Recipients
			$mail->setFrom($email);
			$mail->addAddress('abuhaneephconcepts@gmail.com');     //Add a recipient
		   // $mail->addAddress('ellen@example.com');               //Name is optional
			//$mail->addReplyTo('info@example.com', 'Information');
			//$mail->addCC('cc@example.com');
			//$mail->addBCC('bcc@example.com');
		
			//Attachments
		   // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
			//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
		
			//Content
			$mail->isHTML(true);                                  //Set email format to HTML
			$mail->Subject = $subj;
			$mail->Body    = $body;
			$mail->AltBody = strip_tags($body);
		
			$mail->send();
			echo "<script> alert('Your Message was sent successfully') </script>";
		} catch (Exception $e) {
			echo "<script> Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}
	}
}
?>


<!DOCTYPE html>
<html lang="en">
	<?php include("../partials/header.php") ?>
    <body>		
		<?php include("../partials/nav.php") ?>						
			
		
			<section class="header_text sub">
			<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
				<h4><span>Contact Us</span></h4>
			</section>
			<section class="main-content">				
				<div class="row">				
					<div class="span5">
						<div>
							<h5>ADDITIONAL INFORMATION</h5>
							<p><strong>Phone:</strong>&nbsp;(123) 456-7890<br>
							<strong>Fax:</strong>&nbsp;+04 (123) 456-7890<br>
							<strong>Email:</strong>&nbsp;<a href="#">vietcuong_it@yahoo.com</a>								
							</p>
							<br/>
							<h5>SECONDARY OFFICE IN VIETNAM</h5>
							<p><strong>Phone:</strong>&nbsp;(113) 023-1125<br>
							<strong>Fax:</strong>&nbsp;+04 (113) 023-1145<br>
							<strong>Email:</strong>&nbsp;<a href="#">vietcuong_it@yahoo.com</a>					
							</p>
						</div>
					</div>
					<div class="span7">
						<p>For more enquiry you can contact via the below Contact Us Form </p>
						<form method="post" action="contact.php">
							<fieldset>
								<div class="clearfix">
									<label for="name"><span>Name:</span></label>
									<div class="input">
									<input tabindex="2" size="25" id="user" placeholder="<?php echo $nameErr ?>" name="user" type="text" value="<?php echo $name ?>" class="input-xlarge" >
									
									</div>
								</div>
								<div class="clearfix">
									<label for="name"><span>Subject:</span></label>
									<div class="input">
									<input tabindex="2" size="25" id="subject" placeholder="<?php echo $subjErr ?>" name="subj" type="text" value="<?php echo $subj ?>" class="input-xlarge" >
									
									</div>
								</div>
								
								
								
								
								
								<div class="clearfix">
									<label for="email"><span>Email:</span></label>
									<div class="input">
										<input tabindex="2" size="25" id="email" placeholder="<?php echo $emailErr ?>" name="email" type="text" value="<?php echo $email ?>" class="input-xlarge" >
									</div>
								</div>
								
								<div class="clearfix">
									<label for="message"><span>Message:</span></label>
									<div class="input">
										<textarea tabindex="3" class="input-xlarge" id="message" name="body" rows="7" placeholder="<?php echo $bodyErr ?>"><?php echo $body ?></textarea>
									
									</div>
								</div>
								
								<div class="actions">
									<button name="submit" tabindex="3" type="submit" class="btn btn-inverse">Send message</button>
								</div>
							</fieldset>
						</form>
					</div>				
				</div>
			</section>			
			<?php include("../partials/footer.php") ?>		
    </body>
</html>
<?php
//Import PHPMailer classes into the global namespace

?>