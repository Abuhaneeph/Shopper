<?php
session_start();
include("../config/config.php");

if(isset($_SESSION['email']) && isset($_SESSION['address']) && isset($_SESSION['city'])
 && isset($_SESSION['name']) && isset($_SESSION['tel'])){
	header("Location: ../payinfo/payment.php");
}


if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])){
 header("Location:../index.php");
}

 $nameErr = $emailErr =$telErr=$addErr=$cityErr="";
$name = $email =$tel=$add=$city="";
 function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if (isset($_POST['place_order'])) {
   if (empty($_POST["fullname"])) {
    $nameErr = "Name is required";
  }else{
	$name = test_input($_POST["fullname"]);
	if(strlen($name) < 3){
		$name="";
		$nameErr="Enter a Valid name";
	}
	if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
		$name="";
		$nameErr = "Only Name with letters and white space allowed";
	  }
	}   
	if (empty($_POST["email"])) {
		$emailErr = "Email is required";
	  } else {
		$email = test_input($_POST["email"]);
	    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		
			$email="";
			$emailErr = "Invalid email format";
		  }  
	}
	  if (empty($_POST["telephone"])) {
		$telErr = "Telephone number is required";
	  } else {
		$tel = test_input($_POST["telephone"]);
		if(strlen($tel)<11){
			$tel="";
            $telErr="Your Tel No should have atleast 11 numbers";
		}
	  }
	  if (empty($_POST["address"])) {
		$addErr = "Address is required";
	  } else {
		$add = test_input($_POST["address"]);
		$regex = '/[A-Za-z0-9\-\\,.]+/';
        $is_valid = preg_match($regex, $add); 
		if(strlen($add)<5){
			$add="";
			$addErr="Your Address should have above 10 chracters";
		}
		if(!$is_valid){
			$add="";
			$addErr="Enter a Valid Address";
		}
	  }
	  
	  if (empty($_POST["city"])) {
		$cityErr = "City is required";
	  }else{
		$city = test_input($_POST["city"]);
		if(strlen($city)<3){
			$city="";
			$cityErr="Enter a valid City";
		}
	}
	    
	if($name && $add && $city && $tel && $email !=""){
		$_SESSION['email']=$email;
		$_SESSION['address']=$add;
		$_SESSION['city']=$city;
		$_SESSION['name']=$name;
		$_SESSION['tel']=$tel;
		
		header("Location: ../payinfo/payment.php");
	   }

	   
	   
}
	   
	
	
	
	 

?>

<!DOCTYPE html>
<html lang="en">

		<?php include("../partials/header.php") ?>
		
    <body>		
	<?php include("../partials/nav.php") ?>	
	<section class="header_text sub">		
	<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
		
</section>
	<section class="main-content">				
	<div class="row">		
	<div class="span7">
	<h4 class="title"><span class="text"><strong>CHECKOUT</strong> FORM</span></h4>	
	
			<form  action="checkout.php" method="post">
	<fieldset>
		<div class="control-group">
			<label class="control-label">Full  Name</label>
			<div class="controls">	
        <input  type="text" name="fullname" class="input-xlarge" placeholder="<?php echo $nameErr; ?>" value="<?php echo $name?>">
      </div>
        </div>
		
		<div class="control-group">
			<label class="control-label">Email</label>
  <div class="controls">
  <input  type="email" name="email" class="input-xlarge" placeholder="<?php echo $emailErr; ?>" value="<?php echo $email?>">
  </div>
</div>

<div class="control-group">
			<label class="control-label">Telephone</label>
			<div class="controls">
  <input type="text"  class="input-xlarge" name="telephone" placeholder="<?php echo $telErr; ?>" value="<?php echo $tel?>">
  </div>
</div>

<div class="control-group">
			<label class="control-label">Address</label>
			<div class="controls">	
  <input class="input-xlarge" type="text" name="address" placeholder="<?php echo $addErr; ?>" value="<?php echo $add?>">
  </div>
</div> 
  
<div class="control-group">
			<label class="control-label">City</label>
			<div class="controls">
  <input class="input-xlarge"  type="text" name="city" placeholder="<?php echo $cityErr; ?>" value="<?php echo $city; ?>">
</div>
</div>

<div class="control-group">
<input tabindex="3" class="btn btn-inverse large" type="submit" name="place_order" value="Checkout">
</div>

</fieldset>
</form>
</div>

</div>
</section>	
<?php include("../partials/footer.php") ?>		
		<script src="../themes/js/common.js"></script>
    </body>
</html>