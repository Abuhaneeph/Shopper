<?php
session_start();
include("../config/config.php");
if(isset($_POST['add_to_cart'])){

//if there is atleast one products
if(isset($_SESSION['cart'])){
	$products_array_id=array_column($_SESSION['cart'],"product_id");
	//Check if product has been added to the cart
	if(!in_array($_POST['product_id'],$products_array_id)){
	// add product to cart
	$product_id=$_POST['product_id'];
	
	$product_array=array(
		'product_id'=>$product_id,
		'product_name'=>$_POST['product_name'],
		'product_image'=>$_POST['product_image'],
		'product_price'=>$_POST['product_price'],
		'product_quantity'=>$_POST['product_quantity']
	);
	
	$_SESSION['cart'][$product_id]=$product_array;

	}else{
		
		echo	"<script>alert('Product has already been added to cart')</script>";
	  }
	//if user is adding first product to cart
	}else{
		$product_id=$_POST['product_id'];
		$product_array=array(
			'product_id'=>$product_id,
			'product_name'=>$_POST['product_name'],
			'product_image'=>$_POST['product_image'],
			'product_price'=>$_POST['product_price'],
			'product_quantity'=>$_POST['product_quantity']
		);
		$_SESSION['cart'][$product_id]=$product_array;
	   
	}


}

if(isset($_GET["action"])){
	if($_GET["action"]== "clearall"){
		unset($_SESSION['cart']);
	}
	if($_GET["action"]=="remove"){
		$product_id=$_GET['id'];
		unset($_SESSION['cart'][$product_id]);
		
	}
}

if(isset($_POST["update"])){
	$product_id=$_POST["id"];
	$product_qty=$_POST["qty"];
	$product=$_SESSION['cart'][$product_id];
	$product['product_quantity']=$product_qty;
	$_SESSION['cart'][$product_id]=$product;
}
?>



<!DOCTYPE html>
<html lang="en">
	<?php include("../partials/header.php") ?>
    <body>		
		<?php include("../partials/nav.php") ?>			
			<section class="header_text sub">
			<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
				<h4><span>Shopping Cart</span></h4>
			</section>
			
			<section class="main-content">				
				<div class="row">
					<div class="span9">					
						<h4 class="title"><span class="text"><strong>Your</strong> Cart</span></h4>
						


						<div class="w3-responsive">
						<table class="w3-table-all">
							<thead>
								<tr>
									<th>Remove</th>
									<th>Image</th>
									<th>Product Name</th>
									<th>Quantity</th>
									<th>Unit Price</th>
									<th>Total</th>
								</tr>
							</thead>
							
							
							<tbody>
							<?php $totalprice = 0; ?>
							<?php if(isset($_SESSION['cart'])) {?>
								
							<?php foreach($_SESSION['cart'] as $key => $value){
								
							?>	
								<tr>
									
									<td><a href="cart.php?action=remove&id=<?php echo $value["product_id"] ?>"><i class="fa fa-trash fa-2x"></i></a></td>
									
									<td><a href="product_detail.php"><img style="width: 100px; height: 100px;" alt="" src="../admin/img/<?php echo $value["product_image"]; ?>"></a></td>
									<td><?php echo $value["product_name"] ?></td>
									<td>
									<form action="cart.php" method="post">
									<span><input type="number" placeholder="<?php echo number_format($value["product_quantity"]);  ?>" class="input-mini" value="<?php $value["product_quantity"];  ?>" name='qty'>
									<input type="hidden" name="id" value="<?php echo $value["product_id"]  ?>">
									<button class="w3-button w3-tiny w3-white w3-border w3-border-deep-orange w3-round-large"  type="submit" name="update">Update</button>
							</span>
								</form>
							    </td>
									<td>$<?php echo $value["product_price"]; ?></td>
									<td>
									<?php $price =0; ?>
									$<?php $price =number_format($value["product_price"] * $value["product_quantity"]); echo $price;?> 
									<?php $totalprice=$totalprice+$value["product_quantity"]*$value["product_price"]; ?>
									
								</td>
								</tr>
								
								
								<?php }?>
								<tr>
								<td> Total: </td>
								<td>$<?php echo  $totalprice;?><td>		
								<td><a href="cart.php?action=clearall"><button class="w3-btn w3-black w3-round-large" type="button">Clear All</button></a></td>
								<td>			<form action="checkout.php" method="GET">
											<button class="w3-btn w3-black w3-round-large" type="submit" id="checkout">Checkout</button>
													</form>
										
							</td>
							<td></td>
							     <tr>
							
							<?php } else{?>
								<tr> No Item added to Cart <tr>

							<?php } ?>	
								<tr>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									 
									<td><strong><?php 
									if(empty($_SESSION['cart'])) {
										$totalprice=0;
									}else{
										$totalprice=$totalprice;
									    $_SESSION['total']=number_format($totalprice);
									
									}
									  
									
									?></strong></td>
									
									
									</tr>		  
							</tbody>
						</table>
								</div>
					
						<hr/>
						
										
					</div>
					<?php include("../partials/subcategory.php") ?>
					<?php include("../partials/random.php") ?>			
					</div>
				</div>
			</section>			
			<?php include("../partials/footer.php") ?>
				
    </body>
</html>