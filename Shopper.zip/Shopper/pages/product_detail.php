<?php include("../config/config.php") ?>
<?php
$id=$_GET['id'];
$category=$_GET['category'];
$sql = "SELECT * FROM products WHERE Product_id=$id";
$result=mysqli_query($connect,$sql);

?>
<!DOCTYPE html>
<html lang="en">
	<?php include("../partials/header.php") ?>
   
    <body>		
		     <?php include("../partials/nav.php") ?>
			<section class="header_text sub">
			<img class="pageBanner" src="../themes/images/pageBanner.png" alt="New products" >
				<h4><span>Product Detail</span></h4>
			</section>
			<?php while($row=mysqli_fetch_array($result)){
			?>	
			<section class="main-content">				
				<div class="row">						
					<div class="span9">
						<div class="row">
							<div class="span4">
								<a href="../admin/img/<?php echo $row['Product_image'] ?>" class="thumbnail" data-fancybox-group="group1" title="Description 1"><img alt="" src="../admin/img/<?php echo $row['Product_image'] ?>" class="w3-image product"></a>												
								
							</div>

							<div class="span5">
								<address>
									<strong>Brand:</strong> <span><?php echo $row['Product_name'] ?></span><br>
									<strong>Category:</strong> <span><?php echo $row['Product_category']?></span><br>
						
									<strong>No. Available in Stock:</strong> <span><?php echo $row['Product_quantity']?></span><br>								
								</address>									
								<h4><strong>Price: $<?php echo $row['Product_price']?></strong></h4>
							</div>
							<div class="span5">
								<form  method="post" action="cart.php">
									
									
									<div class="clearfix">
									<label for="name"><span>Quantity:</span></label>
									<div class="input">
									<input tabindex="2" size="25" id="qty" placeholder="1" value="1" name="product_quantity" type="number"  class="input-xlarge" >
									
									</div>
								</div>
									<p>&nbsp;</p>
									<input type="hidden" name="product_id" value="<?php echo $row['Product_id'] ?>">
									<input type="hidden" name="product_name" value="<?php echo $row['Product_name'] ?>">
									<input type="hidden" name="product_image" value="<?php echo $row['Product_image'] ?>">
									<input type="hidden" name="product_price" value="<?php echo $row['Product_price'] ?>">
									

									
									<button class="btn btn-inverse" name="add_to_cart" type="submit">Add to cart</button>
								</form>
							</div>							
						</div>
						<div class="row">
							<div class="span9">
								<ul class="nav nav-tabs" id="myTab">
									<li class="active"><a href="#home">Description</a></li>
									<li class=""><a href="#profile">Additional Information</a></li>
								</ul>							 
								<div class="tab-content">
									<div class="tab-pane active" id="home"><?php echo $row['Product_desc']?></div>
									<div class="tab-pane" id="profile">
										<table class="table table-striped shop_attributes">	
											<tbody>
												<tr class="">
													<th>Size</th>
													<td><?php echo $row['Product_size'] ?></td>
												</tr>		
												<tr class="alt">
													<th>Colour</th>
													<td><?php echo $row['Product_colour'] ?></td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>							
							</div>
							<?php
							}
							?>		
							<div class="span9">	
								<br>
								<h4 class="title">
									<span class="pull-left"><span class="text"><strong>Related</strong> Products</span></span>
									<span class="pull-right">
										
										
									</span>
								</h4>
								<?php
								$query="SELECT * FROM products WHERE Product_category LIKE '$category%' LIMIT 3";
								$rslt=mysqli_query($connect,$query);

								?>
								<div id="myCarousel-1" class="carousel slide">
									<div class="carousel-inner">
										<div class="active item">
											<ul class="thumbnails listing-products">
												<?php
												while($rows=mysqli_fetch_array($rslt)){
												?>
												<li class="span3">
													<div class="product-box">
														<span class="sale_tag"></span>												
														<a href="product_detail.php?id=<?php echo $rows['Product_id']?>&category=<?php echo $rows['Product_category']?>"><img style="width: 200px; height: 150px;" alt="" src="../admin/img/<?php echo $rows['Product_image']?>"></a><br/>
														<a href="product_detail.php?id=<?php echo $rows['Product_id']?>&category=<?php echo $row['Product_category']?>" class="title"><?php echo $rows['Product_name'] ?></a><br/>
														<a href="product_detail.php?id=<?php echo $rows['Product_id']?>&category=<?php echo $rows['Product_category']?>" class="category"><?php echo $rows['Product_category'] ?></a>
														<p class="price">$<?php echo $rows['Product_price']?></p>
														
													</div>
												</li>

												<?php
												}
												?>		
											
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php include("../partials/subcategory.php") ?>
				<?php include("../partials/bestseller.php") ?>
			<?php include("../partials/footer.php") ?>
		<script>
			$(function () {
				$('#myTab a:first').tab('show');
				$('#myTab a').click(function (e) {
					e.preventDefault();
					$(this).tab('show');
				})
			})
			$(document).ready(function() {
				$('.thumbnail').fancybox({
					openEffect  : 'none',
					closeEffect : 'none'
				});
				
				$('#myCarousel-2').carousel({
                    interval: 2500
                });								
			});
		</script>
    </body>
</html>