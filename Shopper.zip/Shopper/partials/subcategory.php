<div class="span3 col ">
						<div class="block">	
							<ul class="nav nav-list">
								<li class="nav-header active">SUB CATEGORIES</li>
								<li><a href="./products.php?id=<?php echo "Men" ?>">Men & Women </a></li>
								<li><a href="./products.php?id=<?php echo "Kids" ?>">Kids</a></li>
                                <li><a href="./products.php?id=<?php echo "Electronic" ?>">Accessories</a></li>			
							<li><a href="./products.php?id=<?php echo "Fashion"?>">Fashion</a>
						
							</ul>
							<br/>
							<ul class="nav nav-list below">
								<li class="nav-header">MANUFACTURES</li>
								<li>Adidas</li>
								<li>Nike</li>
								<li>Dunlop</li>
								<li>Yamaha</li>
							</ul>
						</div>