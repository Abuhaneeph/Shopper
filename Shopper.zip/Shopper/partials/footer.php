<section id="footer-bar">
<h4 class="w3-center">Navigation</h4>
				<div class="row ">
					<div class="span3">
						
						<div class="w3-bar">
							<span>
							<a href="../index.php" class="w3-bar-item w3-button w3-padding w3-hover-text-deep-orange w3-mobile w3-hover-none w3-border-white w3-bottombar w3-hover-border-black" style="text-decoration:none;">Homepage</a>
						
							<a href="../pages/contact.php" class="w3-bar-item w3-button w3-mobile w3-hover-text-deep-orange  w3-hover-none w3-border-white w3-bottombar w3-hover-border-black"  style="text-decoration:none;">Contact Us</a>

</span>							
</div>					
					</div>
					
					<div class="span5  pull-right ">
						<p class="logo"><img src="../themes/images/logo.png" class="site_logo" alt=""></p>
						<p>Shopper is your number one online shopping site in Nigeria. 
						<br/>
						
					</div>					
				</div>	
			</section>
			<section id="copyright">
				<span class="w3-hover-text-deep-orange">Copyright @Abuhaneeph  All right reserved.</span>
			</section>
		</div>

		<script src="../themes/js/common.js"></script>
		<script src="../themes/js/jquery.flexslider-min.js"></script>
			<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>