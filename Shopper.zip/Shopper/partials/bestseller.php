<?php

  
$sql3="SELECT * FROM products ORDER BY RAND() LIMIT 3";
$qury=mysqli_query($connect,$sql3);

?>
<div class="block">	
								
							<h4 class="title"><strong>Best</strong> Seller</h4>								
							<ul class="small-product">
							
							<?php while($rw=mysqli_fetch_array($qury)) {?>	
						<li class="w3-container w3-padding w3-margin">
							
									<a href="#" title="<?php $rw['Product_name'] ?>" style="font-weight:bold;">
										<img src="../admin/img/<?php echo $rw["Product_image"] ?>" style="width:50px; height:50px;" alt="Praesent tempor sem sodales">
									</a>
									<span  class="w3-padding" style="font-weight: bold;"><?php echo $rw['Product_name'] ?><span>
								</li>
							
							<?php }	?>
							
							</ul>
						</div>
					</div>
				</div>
			</section>
			