<?php
$ID=$_GET['ID'];
$func="SELECT * FROM PRODUCTS WHERE Product_id=$ID";
$reslt=mysqli_query($connect,$func);
?>
<div class="block">
							<h4 class="title">
								<span class="pull-left"><span class="text">Randomize</span></span>
								<span class="pull-right">
									<a class="left button" href="random.php?ID=1" data-slide="prev"></a><a class="right button" href="#myCarousel" data-slide="next"></a>
								</span>
							</h4>
							<div id="myCarousel" class="carousel slide">
								<div class="carousel-inner">
									<div class="active item">
										<ul class="thumbnails listing-products">
											<?php while($list=mysqli_fetch_array($reslt)){ ?>
											<li class="span3">
												<div class="product-box">
													<span class="sale_tag"></span>												
													<img alt="" src="../admin/img/<?php echo $list['Product_image'] ?>"><br/>
													<a href="product_detail.php?id=<?php echo $list['Product_id']?>&category=<?php echo $list['Product_category']?>" class="title"><?php echo $list['Product_name'] ?></a><br/>
													<a href="#" class="category"><?php echo $list['Product_category'] ?></a>
													<p class="price"><?php echo $list['Product_price'] ?></p>
												</div>
											</li>
										<?php } ?>
										</ul>
									</div>
								
								</div>
							</div>
						</div>