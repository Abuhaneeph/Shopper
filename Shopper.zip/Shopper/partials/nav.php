<div class="w3-container">

	<div id="top-bar" class="w3-container w3-deep-orange">						
	<a href="../pages/cart.php" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Your Cart</a>
      <a href="../pages/checkout.php" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Checkout</a>
     							
</div>
		<div id="wrapper">
			
			<div class="w3-bar">
  
			<a href="../index.php" class="w3-bar-item w3-button w3-mobile "><img src="../themes/images/logo.png" class="site_logo" alt=""></a>
 
  <a href="products.php?id=Fashion" class="w3-bar-item w3-text-black w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Fashion</a>
      <a href="products.php?id=Men" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Unisex wears</a>
      <a href="products.php?id=Kids" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Kids wears</a>
      <a href="products.php?id=Electronic" class="w3-bar-item w3-button w3-right w3-mobile  w3-hover-none w3-border-deep-orange w3-bottombar w3-hover-border-black">Accessories</a>
   
</div> 
			