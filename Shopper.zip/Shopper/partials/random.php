<?php

$func="SELECT * FROM products ORDER BY RAND() LIMIT 1";
$reslt=mysqli_query($connect,$func);
?>
<div class="block">
							<h4 class="title">
								<span class="pull-left"><span class="text">Randomize</span></span>
								<span class="pull-right">
									
								</span>
							</h4>
							<div id="myCarousel" class="carousel slide">
								<div class="carousel-inner">
									<div class="active item">
										<ul class="thumbnails listing-products">
											<?php while($list=mysqli_fetch_array($reslt)){ ?>
											<li class="span3">
												<div class="product-box">
													<span class="sale_tag"></span>												
													<img alt="" src="../admin/img/<?php echo $list['Product_image'] ?>" style="width:200px; height:150px"><br/>
													<a href="product_detail.php?id=<?php echo $list['Product_id']?>&category=<?php echo $list['Product_category']?>" class="title"><?php echo $list['Product_name'] ?></a><br/>
													<a href="product_detail.php?id=<?php echo $list['Product_id']?>&category=<?php echo $list['Product_category']?>" class="category"><?php echo $list['Product_category'] ?></a>
													<p class="price">$<?php echo $list['Product_price'] ?></p>
												</div>
											</li>
										<?php } ?>
										</ul>
									</div>
								
								</div>
							</div>
						</div>